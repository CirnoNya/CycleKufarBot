import requests
import os
import json
from loguru import logger
from telegram import send_telegram_text

# databaseID_createpage = os.environ['databaseID_createpage']
databaseID_maindatabase = os.environ['databaseID_maindatabase']
token = os.environ['notion_key']

headers = {
    "Authorization": "Bearer " + token,
    "Content-Type": "application/json",
    "Notion-Version": "2022-06-28"
}


def bandit_database(ads_title, time, url, pics, price):
  
  try:
    createUrl = 'https://api.notion.com/v1/pages'
    newPageData = {
      "parent": {"database_id": databaseID_maindatabase},
      "properties": {
        "Ads Name": {
          "title": [
              {
                "text": {
                  "content": ads_title
                        }
              }
                    ]
          },
          "Time": {
            "rich_text": [
              {
                "text": {
                  "content": time
                        }
              }
                          ]
          },
          "URL": {
            "url": url
          },
          "Pics": {
            "files": [
            {
              "name": "no image",
              "external": {
                "url": pics
                          }
            }
                    ]
            },
          "Price (BYN)": {
            "rich_text": [
              {
                "text": {
                  "content": "Договорная" if price == "Договорная" else f'{price // 100}'
                        }
              }
                          ]
            },
          }
        }
  
    data = json.dumps(newPageData)
    requests.request("POST", createUrl, headers=headers, data=data)
    
    return print('The ads was added to Main Database')

  except:
    logger.add("logs/main_logs.log", mode = "w", backtrace=True, diagnose=True, level="ERROR")
    logger.exception(f'|Error in notion_logs|bandit_database function \n')
    send_telegram_text( f"😶‍🌫Error in notion_logs (Kufar)|bandit_database function| https://replit.com/@VasiaPupkin20/Kufar2#notion_logs.py\n")

