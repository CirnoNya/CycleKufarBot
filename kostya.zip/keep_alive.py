from flask import Flask
from threading import Thread


app = Flask('')

@app.route('/')
def home():
    with open('db.txt', 'r') as file:
      number = file.readlines()
      
      return f" <h1><p>Number of Ads: {len(number)}</p></h1>"

def run():
    app.run(host = '0.0.0.0', port = 8080)

def keep_alive():
    t = Thread(target = run)
    t.start()