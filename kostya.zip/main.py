from keep_alive import keep_alive
import requests
from telegram import send_telegram, send_telegram_text, send_telegram_no_image, send_logstoTelegram
import time
from loguru import logger
from requests.adapters import HTTPAdapter, Retry
from notion_logs import bandit_database
import os


BASE_URL = 'https://cre-api-v2.kufar.by/items-search/v1/engine/v1/search/'
ITEM = 'rendered-paginated?cat=4050&size=500&sort=lst.d&typ=sell&cur=BYR&ot=1&query='
COUNT = 'count?cat=4050&cur=BYR&ot=1&query='
BANDIT = 'gravel'
GSF = '%D0%B3%D1%80%D1%8D%D0%B2%D0%B5%D0%BB'
RU = '%D0%B3%D1%80%D0%B0%D0%B2%D0%B5%D0%BB'
END = 'merida%20silex'
IMAGE_URL = 'https://rms3.kufar.by/v1/gallery/'


s = requests.Session()
retries = Retry(total=7, backoff_factor=0.1, status_forcelist=[ 500, 502, 503, 504, 422 ])
s.mount('https://', HTTPAdapter(max_retries=retries))


keep_alive()

while True:
  
  time.sleep(1)
  start_time = time.time()


  class Moto():

    def count(self, subject):   # Делаю запрос на количество объявлений по каждому слову
      status = s.get(BASE_URL + COUNT + subject)         
      total_number = status.json()['count']
      return total_number
  
    
    def ads(self, subject):      # Делаю запрос по данным рекламы, тут дубли тоже есть
      advertising = s.get(BASE_URL + ITEM + subject)
      full_list_with_duplicates = []
          
      for res in advertising.json()['ads']:
        try:
          full_list_with_duplicates.append({
          'ad_id': res['ad_id'],
          'price': int(res['price_byn']),
          'ad_link': res['ad_link'],
          'name': res['subject'],
          'image': f"{IMAGE_URL}{res['images'][0]['path']}"
  
                                          })
  
        except IndexError: #Если нет фото в рекламе
          full_list_with_duplicates.append({
          'ad_id': res['ad_id'],
          'price': int(res['price_byn']),
          'ad_link': res['ad_link'],
          'name': res['subject'],
          'image': 'no_image'
                                          })
            
      return full_list_with_duplicates

      
    def pagination(self, subject): #Делаю запрос на количество страниц. Если есть next, то уведомляю себя, что нужно дописать код с итерацией страниц. Пока не вижу смысла, мало объявлений
      
      all_pages = s.get(BASE_URL + ITEM + subject)
      for page in all_pages.json()['pagination']['pages']:
        if page['label'] == 'next':
          return True
          

  def db_count():
      
    values = Moto()
    full_moto_count = values.count(GSF) + values.count(BANDIT) + values.count(RU) + values.count(END)
    with open('count.txt', 'r') as file:
      number = file.readline()
      if number != str(full_moto_count):
        main()
        with open('count.txt', 'w') as file:
          file.write(str(full_moto_count))
                  
  
  def reading():
      
    db_list = []
    with open('db.txt', 'r') as file:
      for line in file:
        db_list.append(int(line.strip()))
    return db_list
  
  
  def writing(ad_number):
      
    with open('db.txt', 'a') as file:
      file.write(f'{ad_number}\n')
          
  
  def send_message(price, name, image, link): 
    try:
      if image != 'no_image': 
        if price == 0: #Checking if price is weather an integer or string "Договорная" 
                
          send_telegram(f'⚡<b>{name}</b>, '
                f'Договорная'
                f'\n_______________________________\n'
                f'{link}\n'
                f'_______________________________\n', image)
          bandit_database(name, logs_time(), link, image, "Договорная")
        else:
          send_telegram(f'⚡<b>{name}</b>, '
                f'{price // 100} р.'
                f'\n_______________________________\n'
                f'{link}\n'
                f'_______________________________\n', image)
          bandit_database(name, logs_time(), link, image, price)
  
          
      else: #If there is no image in the ad
        if price == 0:  #Checking if the price is weather an integer or a string "Договорная" 
          send_telegram_no_image(f'⚡<b>{name}</b>, '
                f'Договорная'
                f'\n_______________________________\n'
                f'{link}\n'
                f'_______________________________\n')
          bandit_database(name, logs_time(), link, "No Image", "Договорная")
  
        else:
          send_telegram_no_image(f'⚡<b>{name}</b>, ' 
                f'{price // 100} р.'
                f'\n_______________________________\n'
                f'{link}\n'
                f'_______________________________\n')
          bandit_database(name, logs_time(), link, "No Image", price)
  
    except TypeError: #If there is no NEW ad
      pass

    
  def logs_time():
    os.environ['TZ'] = 'Europe/Moscow'
    time.tzset()
    time_string = time.strftime("%d.%m.%Y, %H:%M:%S")
    
    return time_string
    
    
  def main():    
      
    mymoto = Moto()
    full_moto_description = mymoto.ads(GSF) + mymoto.ads(BANDIT) + mymoto.ads(RU) + mymoto.ads(END)
    full_pages = mymoto.pagination(GSF), mymoto.pagination(BANDIT), mymoto.pagination(RU)
    
    for each_moto_ad in full_moto_description:
      if each_moto_ad['ad_id'] not in reading():
        send_message(each_moto_ad['price'], each_moto_ad['name'], each_moto_ad['image'], each_moto_ad['ad_link'])

        writing(each_moto_ad['ad_id'])

    for each_page in full_pages: #Если тут отправляю запрос, значит нужно редачить код на pagination. 89 строка
      if each_page == True:
        send_telegram_text(f'More than 1 page in the api-call. Take actions\n'
                          f'GSF: {mymoto.pagination(GSF)} | BANDIT: {mymoto.pagination(BANDIT)} | RU: {mymoto.pagination(RU)}\n')
      
  
  if __name__ == '__main__':
    try:
      db_count()
  
      
    except Exception: 
      logger.add("logs/main_logs.log", mode = "w", backtrace=True, diagnose=True, level="ERROR")
      logger.exception( f'|Error|\n')
      send_telegram_text(f"😶‍🌫Smth bad happened (Kufar). Reconnect in 5 minutes")
      
      #Отправляем еще лог файл в телегу об полной ошибки
      send_logstoTelegram(logs_time())
      #Спим 30 минут (отпимальное время для перезагрузки и чтобы не записывать повторную ошибку дважды)
      time.sleep(1800)
 
  print(f"The Script has executed in %s seconds" % (round(time.time() - start_time, 2)))
  