import requests
import os


token = os.environ['key_token']
alert = os.environ['alert']
url = "https://api.telegram.org/bot"
channel_id = os.environ['t_channel_id']


def send_telegram(caption, photo):
  method = url + token + "/sendPhoto"
  requests.post(method, data={
    "chat_id": channel_id,
    "caption": caption,
    "parse_mode": "HTML",
    "photo": photo
  })


def send_telegram_text(text: str):
  method = url + alert + "/sendMessage"
  requests.post(method, data={
    "chat_id": channel_id,
    "text": text,
    "parse_mode": "HTML"
  })


def send_telegram_no_image(text: str):
  method = url + token + "/sendMessage"
  requests.post(method, data={
    "chat_id": channel_id,
    "text": text,
    "parse_mode": "HTML"
  })


def send_logstoTelegram(logtime):
  
  # Открываем файл лога и читаем его содержимое
  with open(rb'logs/main_logs.log', encoding='utf8') as f:
      log_data = f.read()
  
  # Отправляем файл в Telegram через API
  url = f'https://api.telegram.org/bot{alert}/sendDocument'
  data = {'chat_id': channel_id}
  files = {'document': (f'{logtime}.log', log_data)}
  response = requests.post(url, data=data, files=files)
  
  # Проверяем статус ответа
  if response.status_code == 200:
      print('Лог-файл успешно отправлен в Telegram!')
  else:
      print(send_telegram_text(f'Ошибка отправки лог-файла в Telegram: {response.text}'))
